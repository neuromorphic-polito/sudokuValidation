User projects
=============

Below is a gallery of example projects developed by us using GeNN.
