#pragma once

// GeNN includes
#include "gennExport.h"

namespace GeNN
{
GENN_EXPORT unsigned int binomialInverseCDF(double cdf, unsigned int n, double p);
}
